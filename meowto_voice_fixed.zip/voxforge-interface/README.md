# Meowto Voice — updated interface

## What changed
- Audio file picker, drag/drop, supported-extension validation, 50 MB size limit, repeat-selection support, and IndexedDB saving improvements.
- Eleven persistent workspace themes: Void Blue, Purple, Red, Green, Pink, Ocean, Midnight, Sunset, Cyber, Light, Dark.
- Weekly chip reset logic at Sunday 23:00 South African time (SAST / UTC+2), with next-reset display.

## Important limitations
This project is a static GitHub Pages front end. Audio samples and chip balances are stored locally in the browser/device. This is not a real server upload and does not sync across devices. A backend with authenticated storage is needed for actual server uploads and a secure shared chip balance. A browser-only reset cannot be made tamper-proof against a user changing their device clock or local storage.

The voice-generation button remains a placeholder until a voice synthesis API/backend is connected.

## Publish
Upload `index.html`, `style.css`, and `app.js` to the repository root, then deploy from GitHub Pages (`main` branch, `/ (root)`).
